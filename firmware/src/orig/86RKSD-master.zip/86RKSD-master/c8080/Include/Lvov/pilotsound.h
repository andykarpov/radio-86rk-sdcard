void pilotSoundStart() @ "pilotsound.c";
void pilotSoundStop() @ "pilotsound.c";
void pilotSound(uchar period, uint delay) @ "pilotsound.c";