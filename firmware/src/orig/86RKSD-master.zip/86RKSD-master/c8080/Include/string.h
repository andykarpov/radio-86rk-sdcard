uint  strlen(const char* s) @ "strlen.c";
char* strcpy(char* d, const char* s) @ "strcpy.c";
char  strcmp(const char* d, const char* s) @ "strcmp.c";
const char* strchr(const char* d, char s) @ "strchr.c";
