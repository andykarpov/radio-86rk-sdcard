#include <apogey/screen_constrcutor.h>

void apogeyScreen2b() {
  APOGEY_SCREEN_ECONOMY_EXT(37, 31, 3, 0x77, 78, 1, 1, 0);
}
