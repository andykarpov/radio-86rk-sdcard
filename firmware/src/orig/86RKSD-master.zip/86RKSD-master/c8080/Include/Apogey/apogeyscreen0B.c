#include <apogey/screen_constrcutor.h>

void apogeyScreen0b() {
  APOGEY_SCREEN_STD(0xE1D0, 30, 25, 3, 0x99, 78, 1, 1, 0);
}
