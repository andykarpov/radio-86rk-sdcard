void drawWindow(const char* title);
void drawInput(uchar* a, uchar a1, uchar max);
void drawError(const char* text, uchar e);
char inputBox(const char* title);
char inputBoxR(const char* title);