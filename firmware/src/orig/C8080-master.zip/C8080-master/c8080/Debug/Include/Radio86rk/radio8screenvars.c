#include <radio86rk/screen_constrcutor.h>

uchar* radio86rkVideoMem = (uchar*)(0x35D0 + 78*3 + 8);
uchar  radio86rkVideoBpl = 78;