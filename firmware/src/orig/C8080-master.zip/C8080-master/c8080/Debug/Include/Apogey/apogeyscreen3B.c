#include <apogey/screen_constrcutor.h>

void apogeyScreen3b() {
  APOGEY_SCREEN_ECONOMY_EXT(64, 51, 7, 0x33, 78, 1, 1, 1);
}
