#include <apogey/screen_constrcutor.h>

void apogeyScreen2a() {
  APOGEY_SCREEN_ECONOMY(0xE1D0, 37, 31, 3, 0x77, 75, 1, 0, 0);
}
