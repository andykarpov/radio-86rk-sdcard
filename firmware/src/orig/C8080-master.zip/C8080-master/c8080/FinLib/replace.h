#include <finlib/std.h>

std::string replace(const std::string& f, const std::string& t, const std::string& str);
std::wstring replace(const std::wstring& f, const std::wstring& t, const std::wstring& str);
