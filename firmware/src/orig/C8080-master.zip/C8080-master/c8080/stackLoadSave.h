#include "common.h"
/*
void peekA();
void pushA();
void pokeA();

void pushD();

void peekHL(bool saveDE=false);
void pushHL();

void pushBC();
bool pokeHL_checkDE();
void peekDE(bool canSwap, bool saveHL);
void pushDE(bool canSwap=false);

void popB();

void popC();

bool pushHLDE(bool canSwap=false, bool self=false);

void pokeHL();

void useA();
void useHL();

void asm_arg(cstring fnName, CType type, int n, bool last);
*/